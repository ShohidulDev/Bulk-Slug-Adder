<?php
/**
 * Plugin Name: Bulk Slug Adder
 * Description: Append any suffix to slugs — all posts or hand-picked ones. By Shohidul Dev | #shohiduldev
 * Version:     3.0.0
 * Author:      Shohidul Dev
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class BSA_Bulk_Slug_Adder {

    public function __construct() {
        add_action( 'admin_menu',                [ $this, 'add_menu' ] );
        add_action( 'wp_ajax_bsa_get_counts',    [ $this, 'ajax_get_counts' ] );
        add_action( 'wp_ajax_bsa_get_posts',     [ $this, 'ajax_get_posts' ] );
        add_action( 'wp_ajax_bsa_run',           [ $this, 'ajax_run' ] );
        add_action( 'admin_enqueue_scripts',     [ $this, 'enqueue' ] );
    }

    public function add_menu() {
        add_menu_page(
            'Bulk Slug Adder', 'Bulk Slug Adder', 'manage_options',
            'bsa-bulk-slug-adder', [ $this, 'render_page' ],
            'dashicons-admin-links', 81
        );
    }

    public function enqueue( $hook ) {
        if ( $hook !== 'toplevel_page_bsa-bulk-slug-adder' ) return;
        wp_add_inline_style( 'wp-admin', $this->css() );
    }

    public function render_page() {
        $post_types = get_post_types( [ 'public' => true ], 'objects' );
        ?>
        <div class="bsa-wrap">

            <div class="bsa-header">
                <span class="bsa-icon">🔗</span>
                <div>
                    <h1>Bulk Slug Adder</h1>
                    <p>Append a suffix to post slugs — all at once or pick exactly which ones &nbsp;·&nbsp;
                       <strong>Shohidul Dev</strong> &nbsp;<span class="bsa-tag">#shohiduldev</span></p>
                </div>
            </div>

            <!-- Settings -->
            <div class="bsa-card">
                <h2>Settings</h2>
                <div class="bsa-grid">
                    <div class="bsa-field">
                        <label for="bsa-post-type">Post Type</label>
                        <select id="bsa-post-type" onchange="bsaOnTypeChange()">
                            <?php foreach ( $post_types as $pt ) : ?>
                                <option value="<?php echo esc_attr($pt->name); ?>">
                                    <?php echo esc_html($pt->labels->singular_name); ?>
                                    (<?php echo esc_html($pt->name); ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="bsa-field">
                        <label for="bsa-suffix">Suffix to Append</label>
                        <input type="text" id="bsa-suffix" value="-07510635870"
                               placeholder="e.g. -07510635870" oninput="bsaUpdateSQL()">
                    </div>
                </div>

                <!-- Mode toggle -->
                <div class="bsa-mode-tabs">
                    <button class="bsa-tab active" id="tab-all" onclick="bsaSetMode('all')">
                        ⚡ All Posts
                    </button>
                    <button class="bsa-tab" id="tab-pick" onclick="bsaSetMode('pick')">
                        ☑️ Select Specific Posts
                    </button>
                </div>

                <!-- ALL mode -->
                <div id="bsa-mode-all">
                    <div class="bsa-sql" id="bsa-sql-preview">Loading...</div>
                    <div class="bsa-info">
                        ✅ <strong>Safe</strong> — posts already having the suffix are skipped<br>
                        ⚡ <strong>Batch mode</strong> — 500 rows per request, no timeout<br>
                        🔄 <strong>Live progress</strong> bar
                    </div>
                    <div class="bsa-stats">
                        <div class="bsa-stat">
                            <div class="bsa-stat-num" id="bsa-pending">—</div>
                            <div class="bsa-stat-label">Pending</div>
                        </div>
                        <div class="bsa-stat bsa-stat-done">
                            <div class="bsa-stat-num" id="bsa-done">—</div>
                            <div class="bsa-stat-label">Already Done</div>
                        </div>
                        <div class="bsa-stat bsa-stat-total">
                            <div class="bsa-stat-num" id="bsa-total">—</div>
                            <div class="bsa-stat-label">Total Posts</div>
                        </div>
                    </div>
                </div>

                <!-- PICK mode -->
                <div id="bsa-mode-pick" style="display:none;">
                    <div class="bsa-pick-toolbar">
                        <input type="text" id="bsa-search" placeholder="Search posts..." oninput="bsaFilterList()">
                        <button class="bsa-btn bsa-btn-sm bsa-btn-outline" onclick="bsaSelectAll()">Select All</button>
                        <button class="bsa-btn bsa-btn-sm bsa-btn-outline" onclick="bsaSelectNone()">Select None</button>
                        <span id="bsa-pick-count" class="bsa-pick-badge">0 selected</span>
                    </div>
                    <div class="bsa-post-list" id="bsa-post-list">
                        <div class="bsa-loading">Loading posts...</div>
                    </div>
                </div>

                <!-- Progress (shared) -->
                <div id="bsa-progress-wrap" style="display:none;margin-top:16px;">
                    <div class="bsa-progress-bar-wrap">
                        <div class="bsa-progress-bar" id="bsa-bar"></div>
                    </div>
                    <div class="bsa-progress-text" id="bsa-progress-text">Starting...</div>
                </div>

                <div id="bsa-result"></div>

                <div class="bsa-actions">
                    <button id="bsa-preview-btn" class="bsa-btn bsa-btn-outline" onclick="bsaPreview()">
                        👀 Preview (first 10)
                    </button>
                    <button id="bsa-run-btn" class="bsa-btn" onclick="bsaConfirm()">
                        ⚡ Run Now
                    </button>
                </div>
            </div>

            <!-- Preview table -->
            <div id="bsa-preview-table" style="display:none;" class="bsa-card">
                <h2>Preview — first 10 slugs</h2>
                <div id="bsa-preview-content"></div>
            </div>

            <div class="bsa-footer">
                Built by <strong>Shohidul Dev</strong> ·
                <a href="https://github.com/shohiduldev" target="_blank">#shohiduldev</a>
            </div>
        </div>

        <script>
        const bsaNonce = '<?php echo wp_create_nonce("bsa_nonce"); ?>';
        const ajaxUrl  = '<?php echo admin_url("admin-ajax.php"); ?>';
        let   bsaMode  = 'all';
        let   bsaPending = 0, bsaDone = 0;
        let   allPosts = []; // for pick mode

        document.addEventListener('DOMContentLoaded', () => { bsaLoadCounts(); bsaUpdateSQL(); });

        function getPostType() { return document.getElementById('bsa-post-type').value; }
        function getSuffix()   { return document.getElementById('bsa-suffix').value.trim(); }

        /* ---- Mode ---- */
        function bsaSetMode(mode) {
            bsaMode = mode;
            document.getElementById('tab-all').classList.toggle('active', mode === 'all');
            document.getElementById('tab-pick').classList.toggle('active', mode === 'pick');
            document.getElementById('bsa-mode-all').style.display  = mode === 'all'  ? 'block' : 'none';
            document.getElementById('bsa-mode-pick').style.display = mode === 'pick' ? 'block' : 'none';
            document.getElementById('bsa-preview-table').style.display = 'none';
            if (mode === 'pick' && allPosts.length === 0) bsaLoadPosts();
        }

        function bsaOnTypeChange() { bsaUpdateSQL(); bsaLoadCounts(); allPosts = []; if (bsaMode==='pick') bsaLoadPosts(); }

        /* ---- SQL preview ---- */
        function bsaUpdateSQL() {
            const pt  = getPostType();
            const sfx = getSuffix() || '-YOUR_SUFFIX';
            document.getElementById('bsa-sql-preview').innerHTML =
                `UPDATE wp_posts<br>` +
                `SET post_name = CONCAT(post_name, '<span class="bsa-highlight">${sfx}</span>')<br>` +
                `WHERE post_type = '${pt}'<br>AND post_status = 'publish'<br>` +
                `AND post_name NOT LIKE '%${sfx}';`;
        }

        /* ---- Counts (all mode) ---- */
        function bsaLoadCounts() {
            ['bsa-pending','bsa-done','bsa-total'].forEach(id => document.getElementById(id).textContent = '...');
            post('bsa_get_counts', {post_type: getPostType(), suffix: getSuffix()}).then(d => {
                if (!d.success) return;
                bsaPending = d.data.pending; bsaDone = d.data.done;
                document.getElementById('bsa-pending').textContent = bsaPending.toLocaleString();
                document.getElementById('bsa-done').textContent    = bsaDone.toLocaleString();
                document.getElementById('bsa-total').textContent   = (bsaPending+bsaDone).toLocaleString();
                document.getElementById('bsa-run-btn').textContent = `⚡ Run Now (${bsaPending.toLocaleString()} rows)`;
            });
        }

        /* ---- Load posts (pick mode) ---- */
        function bsaLoadPosts() {
            document.getElementById('bsa-post-list').innerHTML = '<div class="bsa-loading">Loading posts...</div>';
            post('bsa_get_posts', {post_type: getPostType(), suffix: getSuffix()}).then(d => {
                if (!d.success) return;
                allPosts = d.data;
                bsaRenderList(allPosts);
            });
        }

        function bsaRenderList(posts) {
            if (!posts.length) {
                document.getElementById('bsa-post-list').innerHTML = '<div class="bsa-loading">No pending posts found.</div>';
                return;
            }
            let html = '';
            posts.forEach(p => {
                html += `<label class="bsa-post-item">
                    <input type="checkbox" class="bsa-chk" value="${p.id}" checked onchange="bsaUpdatePickCount()">
                    <span class="bsa-post-title">${p.title}</span>
                    <code class="bsa-post-slug">${p.slug}</code>
                </label>`;
            });
            document.getElementById('bsa-post-list').innerHTML = html;
            bsaUpdatePickCount();
        }

        function bsaFilterList() {
            const q = document.getElementById('bsa-search').value.toLowerCase();
            const filtered = allPosts.filter(p => p.title.toLowerCase().includes(q) || p.slug.toLowerCase().includes(q));
            bsaRenderList(filtered);
        }

        function bsaSelectAll()  { document.querySelectorAll('.bsa-chk').forEach(c => c.checked = true);  bsaUpdatePickCount(); }
        function bsaSelectNone() { document.querySelectorAll('.bsa-chk').forEach(c => c.checked = false); bsaUpdatePickCount(); }

        function bsaUpdatePickCount() {
            const n = document.querySelectorAll('.bsa-chk:checked').length;
            document.getElementById('bsa-pick-count').textContent = `${n} selected`;
            document.getElementById('bsa-run-btn').textContent = `⚡ Run Now (${n} posts)`;
        }

        function getSelectedIds() {
            return [...document.querySelectorAll('.bsa-chk:checked')].map(c => c.value);
        }

        /* ---- Confirm & Run ---- */
        function bsaConfirm() {
            const sfx = getSuffix();
            if (!sfx) { alert('Please enter a suffix first.'); return; }
            if (bsaMode === 'pick') {
                const ids = getSelectedIds();
                if (!ids.length) { alert('Please select at least one post.'); return; }
                if (!confirm(`Append "${sfx}" to ${ids.length} selected post(s)?\n\nMake sure you have a database backup.`)) return;
                bsaRunPick(ids, 0, 0);
            } else {
                if (!confirm(`Append "${sfx}" to ${bsaPending.toLocaleString()} posts of type "${getPostType()}"?\n\nMake sure you have a database backup.`)) return;
                bsaRunAll(0, 0);
            }
        }

        function bsaStartUI() {
            document.getElementById('bsa-progress-wrap').style.display = 'block';
            document.getElementById('bsa-bar').style.width = '0%';
            document.getElementById('bsa-bar').style.background = '#2563eb';
            document.getElementById('bsa-run-btn').disabled     = true;
            document.getElementById('bsa-preview-btn').disabled = true;
            document.getElementById('bsa-result').innerHTML     = '';
        }

        function bsaEndUI(updated, sfx) {
            document.getElementById('bsa-progress-text').textContent = `✅ Done! ${updated.toLocaleString()} slugs updated.`;
            document.getElementById('bsa-bar').style.background = '#22c55e';
            document.getElementById('bsa-result').innerHTML =
                `<div class="bsa-alert bsa-alert-success">✅ Complete! <strong>${updated.toLocaleString()}</strong> slug(s) updated with <strong>${sfx}</strong>. Rewrite rules flushed.</div>`;
            document.getElementById('bsa-run-btn').disabled     = false;
            document.getElementById('bsa-preview-btn').disabled = false;
            bsaLoadCounts();
        }

        function bsaProgress(updated, total) {
            const pct = total > 0 ? Math.min(100, Math.round((updated/total)*100)) : 100;
            document.getElementById('bsa-bar').style.width           = pct + '%';
            document.getElementById('bsa-progress-text').textContent = `${updated.toLocaleString()} / ${total.toLocaleString()} (${pct}%)`;
        }

        /* ALL mode batching */
        function bsaRunAll(offset, updated) {
            if (offset === 0) bsaStartUI();
            const total = bsaPending;
            post('bsa_run', {mode:'run_all', post_type: getPostType(), suffix: getSuffix(), batch:500}).then(d => {
                if (!d.success) { showError(d.data); return; }
                updated += d.data.updated;
                bsaProgress(updated, total);
                document.getElementById('bsa-pending').textContent = Math.max(0, total-updated).toLocaleString();
                if (d.data.has_more) { bsaRunAll(offset+500, updated); }
                else                 { bsaEndUI(updated, getSuffix()); }
            });
        }

        /* PICK mode — send IDs in chunks of 100 */
        function bsaRunPick(ids, offset, updated) {
            if (offset === 0) bsaStartUI();
            const total  = ids.length;
            const chunk  = ids.slice(offset, offset + 100);
            if (!chunk.length) { bsaEndUI(updated, getSuffix()); return; }
            post('bsa_run', {mode:'run_pick', suffix: getSuffix(), ids: chunk.join(',')}).then(d => {
                if (!d.success) { showError(d.data); return; }
                updated += d.data.updated;
                bsaProgress(updated, total);
                bsaRunPick(ids, offset+100, updated);
            });
        }

        function showError(msg) {
            document.getElementById('bsa-result').innerHTML = `<div class="bsa-alert bsa-alert-error">❌ Error: ${msg}</div>`;
            document.getElementById('bsa-run-btn').disabled     = false;
            document.getElementById('bsa-preview-btn').disabled = false;
        }

        /* ---- Preview ---- */
        function bsaPreview() {
            const sfx = getSuffix();
            if (!sfx) { alert('Please enter a suffix first.'); return; }
            const body = bsaMode === 'pick'
                ? {mode:'preview_pick', suffix:sfx, ids: getSelectedIds().slice(0,10).join(',')}
                : {mode:'preview_all',  suffix:sfx, post_type: getPostType()};
            post('bsa_run', body).then(d => {
                if (!d.success) return;
                if (!d.data.length) {
                    document.getElementById('bsa-preview-content').innerHTML = '<p>No pending slugs found.</p>';
                } else {
                    let html = '<table class="bsa-table"><thead><tr><th>Post Title</th><th>Old Slug</th><th>New Slug</th></tr></thead><tbody>';
                    d.data.forEach(r => {
                        html += `<tr><td>${r.title}</td><td><code>${r.old}</code></td><td><code class="bsa-new">${r.new}</code></td></tr>`;
                    });
                    html += '</tbody></table>';
                    document.getElementById('bsa-preview-content').innerHTML = html;
                }
                document.getElementById('bsa-preview-table').style.display = 'block';
            });
        }

        /* ---- Helpers ---- */
        function post(action, data) {
            const body = Object.entries({action, nonce: bsaNonce, ...data})
                .map(([k,v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join('&');
            return fetch(ajaxUrl, {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body}).then(r=>r.json());
        }
        </script>
        <?php
    }

    /* ================================================================== */
    /* AJAX handlers                                                        */
    /* ================================================================== */

    private function check() {
        check_ajax_referer( 'bsa_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );
    }

    public function ajax_get_counts() {
        $this->check();
        global $wpdb;
        $pt   = sanitize_key( $_POST['post_type'] ?? 'post' );
        $sfx  = sanitize_text_field( $_POST['suffix'] ?? '' );
        $like = '%' . $wpdb->esc_like( $sfx );
        $pending = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type=%s AND post_status='publish' AND post_name NOT LIKE %s", $pt, $like ) );
        $done = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type=%s AND post_status='publish' AND post_name LIKE %s", $pt, $like ) );
        wp_send_json_success( compact( 'pending', 'done' ) );
    }

    public function ajax_get_posts() {
        $this->check();
        global $wpdb;
        $pt   = sanitize_key( $_POST['post_type'] ?? 'post' );
        $sfx  = sanitize_text_field( $_POST['suffix'] ?? '' );
        $like = '%' . $wpdb->esc_like( $sfx );
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT ID, post_title, post_name FROM {$wpdb->posts}
             WHERE post_type=%s AND post_status='publish' AND post_name NOT LIKE %s
             ORDER BY post_title ASC LIMIT 2000",
            $pt, $like
        ) );
        $data = array_map( fn($r) => [
            'id'    => (int) $r->ID,
            'title' => esc_html( $r->post_title ),
            'slug'  => $r->post_name,
        ], $rows );
        wp_send_json_success( $data );
    }

    public function ajax_run() {
        $this->check();
        global $wpdb;
        $mode = sanitize_text_field( $_POST['mode'] ?? '' );
        $sfx  = sanitize_text_field( $_POST['suffix'] ?? '' );
        if ( empty( $sfx ) ) wp_send_json_error( 'Suffix is empty.' );

        /* ---------- PREVIEW ALL ---------- */
        if ( $mode === 'preview_all' ) {
            $pt   = sanitize_key( $_POST['post_type'] ?? 'post' );
            $like = '%' . $wpdb->esc_like( $sfx );
            $rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT ID, post_title, post_name FROM {$wpdb->posts}
                 WHERE post_type=%s AND post_status='publish' AND post_name NOT LIKE %s LIMIT 10",
                $pt, $like ) );
            wp_send_json_success( array_map( fn($r) => [
                'title' => esc_html($r->post_title), 'old' => $r->post_name, 'new' => $r->post_name.$sfx ], $rows ) );
        }

        /* ---------- PREVIEW PICK ---------- */
        if ( $mode === 'preview_pick' ) {
            $ids = $this->parse_ids( $_POST['ids'] ?? '' );
            if ( empty($ids) ) wp_send_json_success([]);
            $ph   = implode(',', array_fill(0,count($ids),'%d'));
            $rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT ID, post_title, post_name FROM {$wpdb->posts} WHERE ID IN ($ph)", ...$ids ) );
            wp_send_json_success( array_map( fn($r) => [
                'title'=>esc_html($r->post_title),'old'=>$r->post_name,'new'=>$r->post_name.$sfx], $rows ) );
        }

        /* ---------- RUN ALL ---------- */
        if ( $mode === 'run_all' ) {
            $pt    = sanitize_key( $_POST['post_type'] ?? 'post' );
            $batch = min( 500, (int)($_POST['batch']??500) );
            $like  = '%' . $wpdb->esc_like( $sfx );
            $ids   = $wpdb->get_col( $wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts}
                 WHERE post_type=%s AND post_status='publish' AND post_name NOT LIKE %s LIMIT %d",
                $pt, $like, $batch ) );
            $updated = $this->apply_suffix( $ids, $sfx );
            $has_more = count($ids) === $batch;
            if (!$has_more) flush_rewrite_rules();
            wp_send_json_success( compact('updated','has_more') );
        }

        /* ---------- RUN PICK ---------- */
        if ( $mode === 'run_pick' ) {
            $ids     = $this->parse_ids( $_POST['ids'] ?? '' );
            $updated = $this->apply_suffix( $ids, $sfx );
            flush_rewrite_rules();
            wp_send_json_success( ['updated'=>$updated,'has_more'=>false] );
        }

        wp_send_json_error('Unknown mode.');
    }

    private function apply_suffix( array $ids, string $sfx ): int {
        global $wpdb;
        $updated = 0;
        foreach ( $ids as $id ) {
            $res = $wpdb->query( $wpdb->prepare(
                "UPDATE {$wpdb->posts} SET post_name=CONCAT(post_name,%s) WHERE ID=%d", $sfx, (int)$id ) );
            if ($res) { clean_post_cache((int)$id); $updated++; }
        }
        return $updated;
    }

    private function parse_ids( string $raw ): array {
        return array_filter( array_map('intval', explode(',', $raw)) );
    }

    /* ================================================================== */
    /* CSS                                                                  */
    /* ================================================================== */
    private function css() {
        return '
        .bsa-wrap{max-width:980px;margin:30px auto;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
        .bsa-header{display:flex;align-items:center;gap:16px;margin-bottom:28px}
        .bsa-icon{font-size:42px}
        .bsa-header h1{margin:0;font-size:26px;color:#1a1a2e}
        .bsa-header p{margin:4px 0 0;color:#666;font-size:13px}
        .bsa-tag{background:#e8f0fe;color:#1a73e8;padding:2px 8px;border-radius:99px;font-size:11px;font-weight:600}
        .bsa-card{background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:28px;margin-bottom:24px;box-shadow:0 1px 4px rgba(0,0,0,.06)}
        .bsa-card h2{margin:0 0 20px;font-size:17px;color:#111827}
        .bsa-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px}
        .bsa-field label{display:block;font-weight:600;font-size:13px;color:#374151;margin-bottom:6px}
        .bsa-field input,.bsa-field select{width:100%;padding:10px 14px;border:1.5px solid #d1d5db;border-radius:8px;font-size:14px;box-sizing:border-box;transition:border .2s}
        .bsa-field input:focus,.bsa-field select:focus{border-color:#2563eb;outline:none;box-shadow:0 0 0 3px rgba(37,99,235,.12)}
        .bsa-mode-tabs{display:flex;gap:8px;margin-bottom:20px}
        .bsa-tab{padding:9px 20px;border-radius:8px;border:2px solid #d1d5db;background:#fff;font-size:14px;font-weight:600;cursor:pointer;color:#6b7280;transition:all .2s}
        .bsa-tab.active{border-color:#2563eb;background:#eff6ff;color:#2563eb}
        .bsa-tab:hover:not(.active){border-color:#9ca3af;color:#374151}
        .bsa-sql{background:#0f172a;color:#7dd3fc;font-family:"Courier New",monospace;font-size:13px;padding:18px 20px;border-radius:8px;margin-bottom:16px;line-height:1.9}
        .bsa-highlight{color:#fbbf24;font-weight:700}
        .bsa-info{background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:14px 18px;font-size:13px;color:#166534;line-height:2.1;margin-bottom:20px}
        .bsa-stats{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:20px}
        .bsa-stat{background:#f8fafc;border:1px solid #e5e7eb;border-radius:10px;padding:18px;text-align:center}
        .bsa-stat-done{border-color:#bbf7d0;background:#f0fdf4}
        .bsa-stat-total{border-color:#bfdbfe;background:#eff6ff}
        .bsa-stat-num{font-size:28px;font-weight:700;color:#1a1a2e}
        .bsa-stat-done .bsa-stat-num{color:#16a34a}
        .bsa-stat-total .bsa-stat-num{color:#2563eb}
        .bsa-stat-label{font-size:11px;color:#6b7280;margin-top:4px;text-transform:uppercase;letter-spacing:.05em}
        .bsa-pick-toolbar{display:flex;align-items:center;gap:10px;margin-bottom:12px;flex-wrap:wrap}
        .bsa-pick-toolbar input{flex:1;min-width:200px;padding:8px 12px;border:1.5px solid #d1d5db;border-radius:8px;font-size:13px}
        .bsa-pick-badge{background:#2563eb;color:#fff;padding:4px 12px;border-radius:99px;font-size:12px;font-weight:600;white-space:nowrap}
        .bsa-post-list{max-height:380px;overflow-y:auto;border:1.5px solid #e5e7eb;border-radius:8px;margin-bottom:20px}
        .bsa-post-item{display:flex;align-items:center;gap:10px;padding:10px 14px;border-bottom:1px solid #f1f5f9;cursor:pointer;transition:background .1s}
        .bsa-post-item:last-child{border-bottom:none}
        .bsa-post-item:hover{background:#f8fafc}
        .bsa-post-item input[type=checkbox]{width:16px;height:16px;flex-shrink:0;cursor:pointer}
        .bsa-post-title{font-size:13px;color:#111827;flex:1;font-weight:500}
        .bsa-post-slug{font-size:11px;background:#f1f5f9;padding:2px 8px;border-radius:4px;color:#6b7280;max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
        .bsa-loading{padding:20px;text-align:center;color:#9ca3af;font-size:14px}
        .bsa-progress-bar-wrap{background:#e5e7eb;border-radius:99px;height:12px;margin-bottom:10px;overflow:hidden}
        .bsa-progress-bar{height:100%;background:#2563eb;border-radius:99px;width:0%;transition:width .4s}
        .bsa-progress-text{font-size:14px;color:#374151;margin-bottom:12px;font-weight:600}
        .bsa-actions{display:flex;gap:12px;justify-content:flex-end;margin-top:12px}
        .bsa-btn{padding:11px 26px;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;border:none;transition:all .2s;background:#2563eb;color:#fff}
        .bsa-btn:hover:not(:disabled){background:#1d4ed8}
        .bsa-btn:disabled{opacity:.45;cursor:not-allowed}
        .bsa-btn-outline{background:#fff;color:#2563eb;border:2px solid #2563eb}
        .bsa-btn-outline:hover:not(:disabled){background:#eff6ff}
        .bsa-btn-sm{padding:7px 14px;font-size:12px}
        .bsa-alert{padding:14px 18px;border-radius:8px;font-size:14px;margin-top:12px}
        .bsa-alert-success{background:#f0fdf4;color:#166534;border:1px solid #bbf7d0}
        .bsa-alert-error{background:#fef2f2;color:#991b1b;border:1px solid #fecaca}
        .bsa-table{width:100%;border-collapse:collapse;font-size:13px}
        .bsa-table th{text-align:left;padding:10px 14px;background:#f8fafc;border-bottom:2px solid #e5e7eb;font-size:11px;text-transform:uppercase;color:#6b7280;letter-spacing:.05em}
        .bsa-table td{padding:10px 14px;border-bottom:1px solid #f1f5f9}
        .bsa-table code{background:#f1f5f9;padding:3px 8px;border-radius:4px}
        .bsa-new{background:#dcfce7!important;color:#166534}
        .bsa-footer{text-align:center;color:#9ca3af;font-size:13px;padding:16px 0 8px}
        .bsa-footer a{color:#2563eb;text-decoration:none}
        @media(max-width:640px){.bsa-grid{grid-template-columns:1fr}.bsa-stats{grid-template-columns:1fr}}
        ';
    }
}

new BSA_Bulk_Slug_Adder();
